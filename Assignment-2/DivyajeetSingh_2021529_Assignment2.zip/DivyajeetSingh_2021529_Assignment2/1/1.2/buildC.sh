cd ./1/1.2/kernelbuild/C/linux-5.19.8

sudo make bzImage

echo "Build C done"